package com.example.entrepantallanavegar.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun SecondScreen() {  // ✅ Nombre corregido
    Scaffold { paddingValues ->
        BodyContent(modifier = Modifier.padding(paddingValues))  // ✅ Se usa paddingValues
    }
}

@Composable
fun SecondBodyContent(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize(),  // ✅ fillMaxSize() corregido
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally  // ✅ Nombre corregido
    ) {
        Text("Hola navegación")
        Spacer(modifier = Modifier.height(16.dp))  // ✅ Espaciado opcional
        Button(onClick = { /*TODO*/ }) {
            Text("Navega")  // ✅ Text corregido
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SecondDefaultPreview() {
    SecondScreen()
}

