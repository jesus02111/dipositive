package com.example.navegacionentrepantalla.navigation

open class AppScreens(val route: String) {
    object FirstScreen: AppScreens("first_screen")
    object SecondtScreen: AppScreens("second_screen")
}