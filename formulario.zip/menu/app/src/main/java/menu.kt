package com.example.bdatos

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var txtNombre: EditText
    private lateinit var txtEdad: EditText
    private lateinit var txtTelefono: EditText
    private lateinit var txtCiudad: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtNombre = findViewById(R.id.txtNombre)
        txtEdad = findViewById(R.id.txtEdad)
        txtTelefono = findViewById(R.id.txtTelefono)
        txtCiudad = findViewById(R.id.txtCiudad)
    }

    fun insertar(view: View) {
        val con = SQLite(this, "personasDB", null, 1)
        val baseDatos = con.writableDatabase

        val nombre = txtNombre.text.toString().trim()
        val edad = txtEdad.text.toString().trim()
        val telefono = txtTelefono.text.toString().trim()
        val ciudad = txtCiudad.text.toString().trim()

        if (nombre.isNotEmpty() && edad.isNotEmpty() && telefono.isNotEmpty() && ciudad.isNotEmpty()) {
            val registro = ContentValues().apply {
                put("nombre", nombre)
                put("edad", edad.toInt()) // Convertimos a entero
                put("telefono", telefono)
                put("ciudad", ciudad)
            }
            baseDatos.insert("personas", null, registro)
            baseDatos.close()

            // Limpiar los campos después de insertar
            txtNombre.setText("")
            txtEdad.setText("")
            txtTelefono.setText("")
            txtCiudad.setText("")

            Toast.makeText(this, "Registro insertado exitosamente", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_LONG).show()
        }
    }
}
