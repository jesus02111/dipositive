package com.DartByte.appactualizado

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.DartByte.appactualizado.ui.theme.CardPresentationTheme

// Lista de mensajes de ejemplo
private val messages: List<MyMessage> = listOf(
    MyMessage("Hola Jetpack Compose 1", "Este es un mensaje de ejemplo para demostrar la lista en Jetpack Compose."),
    MyMessage("Hola Jetpack Compose 2", "Aquí puedes agregar otro mensaje para visualizar cómo funciona la UI."),
    MyMessage("Hola Jetpack Compose 3", "Cada mensaje tiene un título y un cuerpo de texto."),
    MyMessage("Hola Jetpack Compose 4", "Puedes hacer clic en los mensajes para expandir su contenido."),
    MyMessage("Hola Jetpack Compose 5", "Este es otro mensaje con un poco más de contenido."),
    MyMessage("Hola Jetpack Compose 6", "Puedes personalizar los colores y el estilo de los textos."),
    MyMessage("Hola Jetpack Compose 7", "Jetpack Compose facilita la creación de listas dinámicas."),
    MyMessage("Hola Jetpack Compose 8", "Puedes modificar esta lista para probar diferentes mensajes."),
    MyMessage("Hola Jetpack Compose 9", "Cada elemento se renderiza en un LazyColumn."),
    MyMessage("Hola Jetpack Compose 10", "Los elementos son renderizados de manera eficiente."),
    MyMessage("Hola Jetpack Compose 11", "Este mensaje demuestra cómo se pueden agregar múltiples elementos."),
    MyMessage("Hola Jetpack Compose 12", "Puedes hacer clic en este mensaje para expandirlo."),
    MyMessage("Hola Jetpack Compose 13", "Es fácil modificar el diseño con MaterialTheme."),
    MyMessage("Hola Jetpack Compose 14", "Puedes cambiar la fuente, el color y el tamaño del texto."),
)

// Actividad principal
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CardPresentationTheme {
                MessageList(messages) // Renderiza la lista de mensajes
            }
        }
    }
}

// Modelo de datos para un mensaje
data class MyMessage(val title: String, val body: String)

// Composable que muestra una lista de mensajes
@Composable
fun MessageList(messages: List<MyMessage>) {
    LazyColumn {
        items(messages) { message ->
            MyComponent(message) // Renderiza cada mensaje individualmente
        }
    }
}

// Composable que representa un mensaje con imagen y texto
@Composable
fun MyComponent(message: MyMessage) {
    Row(
        modifier = Modifier
            .background(MaterialTheme.colorScheme.background)
            .padding(8.dp)
    ) {
        MyImage() // Imagen del mensaje
        MyTexts(message) // Texto del mensaje
    }
}

// Composable que muestra una imagen circular
@Composable
fun MyImage() {
    Image(
        painterResource(R.drawable.ic_launcher_foreground),
        contentDescription = "Imagen de prueba",
        modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary),
    )
}

// Composable que muestra el título y el cuerpo del mensaje
@Composable
fun MyTexts(message: MyMessage) {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .padding(start = 8.dp)
            .clickable { expanded = !expanded } // Expande o colapsa el mensaje al hacer clic
    ) {
        MyText(
            message.title,
            MaterialTheme.colorScheme.primary,
            MaterialTheme.typography.titleMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        MyText(
            message.body,
            MaterialTheme.colorScheme.onBackground,
            MaterialTheme.typography.bodyLarge,
            if (expanded) Int.MAX_VALUE else 1 // Muestra solo una línea si no está expandido
        )
    }
}

// Composable reutilizable para mostrar texto
@Composable
fun MyText(text: String, color: Color, style: TextStyle, lines: Int = Int.MAX_VALUE) {
    Text(text, color = color, style = style, maxLines = lines)
}

// Vista previa del componente en modo claro y oscuro
@Preview(showSystemUi = true)
@Preview(uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun PreviewComponent() {
    CardPresentationTheme {
        MessageList(messages) // Muestra la lista de mensajes en la vista previa
    }
}
